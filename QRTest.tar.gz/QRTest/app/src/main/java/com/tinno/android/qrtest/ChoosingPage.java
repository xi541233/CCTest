package com.tinno.android.qrtest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChoosingPage extends AppCompatActivity
{
    private Button mQRButton;
    private Button mBarButton;
    private EditText mContentEditText;
    private EditText mWidthEditText;
    private EditText mHightEditText;
    private String Content;
    private int Height;
    private int width;

    private List<CheckBox> mCheckBoxList=new ArrayList<>();
    private List<EditText> mValueEditTextList=new ArrayList<>();
    private List<EditText> mTimeEditTextList=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choicing_page);

        mCheckBoxList.add((CheckBox) findViewById(R.id.XTCheckBox));
        mCheckBoxList.add((CheckBox) findViewById(R.id.YTCheckBox));
        mCheckBoxList.add((CheckBox) findViewById(R.id.XRCheckBox));
        mCheckBoxList.add((CheckBox) findViewById(R.id.YRCheckBox));
        mCheckBoxList.add((CheckBox) findViewById(R.id.RCheckBox));
        mValueEditTextList.add((EditText)findViewById(R.id.XTText1));
        mValueEditTextList.add((EditText)findViewById(R.id.YTText1));
        mValueEditTextList.add((EditText)findViewById(R.id.XRText1));
        mValueEditTextList.add((EditText)findViewById(R.id.YRText1));
        mValueEditTextList.add((EditText)findViewById(R.id.RText1));
        mTimeEditTextList.add((EditText)findViewById(R.id.XTText2));
        mTimeEditTextList.add((EditText)findViewById(R.id.YTText2));
        mTimeEditTextList.add((EditText)findViewById(R.id.XRText2));
        mTimeEditTextList.add((EditText)findViewById(R.id.YRText2));
        mTimeEditTextList.add((EditText)findViewById(R.id.RText2));


        mQRButton=findViewById(R.id.QRButton);
        mBarButton=findViewById(R.id.barButton);
        mContentEditText=findViewById(R.id.ContentEdit);
        mHightEditText=findViewById(R.id.hightEdit);
        mWidthEditText=findViewById(R.id.widthEdit);
        mQRButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                putMessage(1);
            }
        });
        mBarButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String a=mContentEditText.getText().toString();
                Pattern p=Pattern.compile("[\u4e00-\u9fa5]");
                Matcher m=p.matcher(a);
                boolean b=m.matches();
                if(b)
                {
                    Toast toast=Toast.makeText(ChoosingPage.this,"中文字符无法生成条形码",Toast.LENGTH_SHORT);
                    toast.show();
                }
                else
                {
                    putMessage(0);
                }

            }
        });
    }
    public void putMessage(int type)
    {
        int XTranslateDis=0,XTranslateTim=0,YTranslateDis=0,YTranslateTim=0,XOrientationAng=0,XOrientationTim=0,
                YOrientationAng=0,YOrientationTim=0,OrientationAng=0,OrientationTim=0;
        try
        {
            Content=mContentEditText.getText().toString();
            Height=Integer.parseInt(mHightEditText.getText().toString());
            width=Integer.parseInt(mWidthEditText.getText().toString());
            if(mCheckBoxList.get(0).isChecked())
            {
                XTranslateDis=Integer.parseInt(mValueEditTextList.get(0).getText().toString());
                XTranslateTim=Integer.parseInt(mTimeEditTextList.get(0).getText().toString());
            }
            if(mCheckBoxList.get(1).isChecked())
            {
                YTranslateDis=Integer.parseInt(mValueEditTextList.get(1).getText().toString());
                YTranslateTim=Integer.parseInt(mTimeEditTextList.get(1).getText().toString());
            }
            if(mCheckBoxList.get(2).isChecked())
            {
                XOrientationAng=Integer.parseInt(mValueEditTextList.get(2).getText().toString());
                XOrientationTim=Integer.parseInt(mTimeEditTextList.get(2).getText().toString());
            }
            if(mCheckBoxList.get(3).isChecked())
            {
                YOrientationAng=Integer.parseInt(mValueEditTextList.get(3).getText().toString());
                YOrientationTim=Integer.parseInt(mTimeEditTextList.get(3).getText().toString());
            }
            if(mCheckBoxList.get(4).isChecked())
            {
                OrientationAng=Integer.parseInt(mValueEditTextList.get(4).getText().toString());
                OrientationTim=Integer.parseInt(mTimeEditTextList.get(4).getText().toString());
            }

            if(Content.length()==0)
            {
                throw new Exception();
            }
        }

        catch (Exception e)
        {
            Toast.makeText(ChoosingPage.this,"请将内容填写完整",Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent=new Intent(ChoosingPage.this,MainActivity.class);
        intent.putExtra("Content",Content);
        intent.putExtra("Height", Height);
        intent.putExtra("Width", width);
        intent.putExtra("type",type);
        intent.putExtra("XTranslateDis",XTranslateDis);
        intent.putExtra("XTranslateTim",XTranslateTim);
        intent.putExtra("YTranslateTim",YTranslateTim);
        intent.putExtra("YTranslateDis",YTranslateDis);
        intent.putExtra("XOrientationAng",XOrientationAng);
        intent.putExtra("XOrientationTim",XOrientationTim);
        intent.putExtra("YOrientationAng",YOrientationAng);
        intent.putExtra("YOrientationTim",YOrientationTim);
        intent.putExtra("OrientationAng",OrientationAng);
        intent.putExtra("OrientationTim",OrientationTim);
        startActivity(intent);
    }

}
