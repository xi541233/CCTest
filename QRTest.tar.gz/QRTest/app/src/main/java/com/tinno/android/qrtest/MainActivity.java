package com.tinno.android.qrtest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.util.Hashtable;
public class MainActivity extends Activity
{
    private static final int barCode=0;
    private static final int cycleTimes=1000;
    /**生成一个二维码和条形码-----*/
    public static Bitmap createCode(String text,int height,int width,int CodeType)
    {

        Bitmap bitmap=null;
        try
        {
            Hashtable<EncodeHintType, Object> hints = new Hashtable<>();
            hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hints.put(EncodeHintType.MARGIN, 1);
            if(CodeType==barCode)
            {
                BitMatrix bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.CODE_128,width,height);

                int[] pixels = new int[width * height];
                for(int y = 0; y < height; y++)
                {
                    for(int x = 0; x < width; x++)
                    {

                        if(bitMatrix.get(x, y))
                        {
                            pixels[y * width + x] = 0xff000000;
                        }
                        else
                        {
                            pixels[y * width + x] = 0xffffffff;
                        }

                    }
                    bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
                }

            }
            else
            {
                BitMatrix bitMatrix = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, height, height, hints);
                int[] pixels = new int[height * height];
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < height; x++)
                    {
                        if (bitMatrix.get(x, y))
                        {
                            pixels[y * height + x] = 0xff000000;
                        }
                        else
                        {
                            pixels[y * height + x] = 0xffffffff;
                        }
                    }
                }
                bitmap = Bitmap.createBitmap(height, height, Bitmap.Config.ARGB_8888);
                bitmap.setPixels(pixels, 0, height, 0, 0, height, height);
            }

        }
        catch (WriterException e)
        {
            e.printStackTrace();
            return null;
        }

        return bitmap;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonRedraw = findViewById(R.id.buttonRedraw);
        Intent intent=getIntent();
        String content=intent.getStringExtra("Content");
        int height=intent.getIntExtra("Height",300);
        int width=intent.getIntExtra("Width",500);
        int type=intent.getIntExtra("type",1);
        int XTranslateDis=intent.getIntExtra("XTranslateDis",0);
        int XTranslateTim=intent.getIntExtra("XTranslateTim",0);
        int YTranslateDis=intent.getIntExtra("YTranslateDis",0);
        int YTranslateTim=intent.getIntExtra("YTranslateTim",0);
        int XOrientationAng=intent.getIntExtra("XOrientationAng",0);
        int XOrientationTim=intent.getIntExtra("XOrientationTim",0);
        int YOrientationAng=intent.getIntExtra("YOrientationAng",0);
        int YOrientationTim=intent.getIntExtra("YOrientationTim",0);
        int OrientationAng=intent.getIntExtra("OrientationAng",0);
        int OrientationTim=intent.getIntExtra("OrientationTim",0);
        Bitmap bitmap=createCode(content, height, width, type);

        ImageView imageView = findViewById(R.id.QRImageView);
        imageView.setImageBitmap(bitmap);
        /**animate one*/
        ObjectAnimator translationAnimX = ObjectAnimator.ofFloat(imageView,
                "translationX", 0f, XTranslateDis,0f,-XTranslateDis,0f);
        translationAnimX.setDuration(XTranslateTim);
        translationAnimX.setRepeatCount(cycleTimes);
        translationAnimX.setRepeatMode(ValueAnimator.REVERSE);
        translationAnimX.setInterpolator(new LinearInterpolator());
        translationAnimX.start();
        ObjectAnimator translationAnimY = ObjectAnimator.ofFloat(imageView,
                "translationY", 0f, YTranslateDis,0f,-YTranslateDis,0f);
        translationAnimY.setDuration(YTranslateTim);
        translationAnimY.setRepeatCount(cycleTimes);
        translationAnimY.setInterpolator(new LinearInterpolator());
        translationAnimY.start();
        ObjectAnimator rotationAnimX = ObjectAnimator.ofFloat(imageView,
                "rotationX", 0,XOrientationAng,0,-XOrientationAng,0);
        rotationAnimX.setDuration(XOrientationTim);
        rotationAnimX.setRepeatCount(cycleTimes);
        rotationAnimX.setInterpolator(new LinearInterpolator());
        rotationAnimX.start();

        ObjectAnimator rotationAnimY = ObjectAnimator.ofFloat(imageView,
                "rotationY", 0f, YOrientationAng,0,-YOrientationAng,0f);
        rotationAnimY.setDuration(YOrientationTim);
        rotationAnimY.setRepeatCount(cycleTimes);
        rotationAnimY.setInterpolator(new LinearInterpolator());
        rotationAnimY.start();

        ObjectAnimator rotationAnim = ObjectAnimator.ofFloat(imageView,
                "rotation", 0f, OrientationAng,0,-OrientationAng,0f);
        rotationAnim.setDuration(OrientationTim);
        rotationAnim.setRepeatCount(cycleTimes);
        rotationAnim.setInterpolator(new LinearInterpolator());
        rotationAnim.start();
       /**animate*/
        buttonRedraw.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });
    }


}
